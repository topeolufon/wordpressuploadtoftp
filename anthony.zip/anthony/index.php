<?php
/**
* Plugin Name: Anthony Demo
* Description: Upload files to FTP with WordPress
* Version: 1.0.0
* Author: Tope Olufon
* Author URI: http://xiungo.com
* License: MIT
*/

add_action('admin_menu', 'plugin_settings');
 
function plugin_settings(){
        add_menu_page( 'Upload Plugin', 'Upload Plugin', 'manage_options', 'upload-plugin', 'menu_init' );
}


function get_ftp(){
  $ftp_values = [];
  $ftp_values["ftp_host"] = get_option('plugin_ftp_host');
  $ftp_values["ftp_port"] = get_option('plugin_ftp_port');
  $ftp_values["ftp_user"] = get_option('plugin_ftp_user');
  $ftp_values["ftp_pass"] = get_option('plugin_ftp_pass');
  $ftp_values["ftp_dir"] = get_option('plugin_ftp_dir');
  return $ftp_values;
}

function ftp_vars() {
 if (isset($_POST['update-ftp'])) {
    update_option('plugin_ftp_host', $_POST['plugin_ftp_host']);
    update_option('plugin_ftp_port', $_POST['plugin_ftp_port']);
    update_option('plugin_ftp_user', $_POST['plugin_ftp_user']);
    if ($_POST['plugin_ftp_pass'] != "**********"){
    update_option('plugin_ftp_pass', $_POST['plugin_ftp_pass']);
    }
    update_option('plugin_ftp_dir', $_POST['plugin_ftp_dir']);
  }
?>
<div class="wrap">
  <h1><strong>DO NOT USE THIS CODE IN PRODUCTION, IT IS NOT RELIABLE YET</strong></h1>
  <h1>Update</h1>
  <p>Change FTP details below</p>
  <form action="<?php echo str_replace('%7E', '~', $_SERVER['REQUEST_URI']); ?>" method="post">
  Host: <input type="text" value="<?php echo  get_ftp()['ftp_host']; ?>" name="plugin_ftp_host" placeholder="FTP Host"><br />
  Port: <input type="number" value="<?php echo  get_ftp()['ftp_port']; ?>" name="plugin_ftp_port" placeholder="FTP Port"><br />
  User: <input type="text" value="<?php echo  get_ftp()['ftp_user']; ?>" name="plugin_ftp_user" placeholder="FTP User"><br />
  Pass: <input type="password" value="<?php echo  "**********"; ?>" name="plugin_ftp_pass" placeholder="FTP Pass"><br />
  Destination Dir: <input type="text" value="<?php echo get_ftp()['ftp_dir']; ?>" name="plugin_ftp_dir" placeholder="FTP Dir"><br />
  <input name="update-ftp" type="hidden" value="1" />
  <input type="submit" value="Submit" />
  </form>
</div>
<?php
}

function menu_init(){
        echo "<h1>Upload to FTP</h1>";
        ftp_vars();
        upload_form();
}



function upload_form(){
?>
        <h2>Upload a File</h2>
        <form  method="post" enctype="multipart/form-data">
                <input type='file' id='file-input' name='file-input'></input>
                <?php submit_button('Upload');
               move_files();
               ?>
                
        </form>
<?php
}

function move_files(){
        if(isset($_FILES['file-input'])){
                $img = $_FILES['file-input'];
                print_r($img);
                // $uploaded=media_handle_upload('file-input', 0);
                // if(is_wp_error($uploaded)){
                //         echo "Error: " . $uploaded->get_error_message();
                // }else{
                    $temp = $img["tmp_name"];
                    $name = $img["name"];
                    $uploads_dir =  __DIR__ .'/'.$name;
                    $host = get_ftp()['ftp_host'];
                    $port = get_ftp()['ftp_port'];
                    $timeout = 1000;
                    $user = get_ftp()['ftp_user'];
                    $pass = get_ftp()['ftp_pass'];
                    $source_file = $img["tmp_name"];
                    $dest_file = get_ftp()['ftp_dir']."/".$name;
                    $ftp = ftp_connect($host,$port,$timeout);
                    ftp_login($ftp,$user,$pass);
                    ftp_pasv($ftp, true);
                    $ret = ftp_nb_put($ftp, $dest_file, $source_file, FTP_BINARY, FTP_AUTORESUME);
                    while (FTP_MOREDATA == $ret)
                        {
                            $ret = ftp_nb_continue($ftp);
                        }
                    echo move_uploaded_file($temp, $uploads_dir);
                    echo "Successful!";
                    echo  $dest_file ;
                // }
        }
}